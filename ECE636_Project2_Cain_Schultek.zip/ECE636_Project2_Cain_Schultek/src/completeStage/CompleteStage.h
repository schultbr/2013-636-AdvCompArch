/*
 * CompleteStage.h
 *
 *  Created on: Oct 29, 2013
 *      Author: jason cain
 */

#ifndef COMPLETESTAGE_H_
#define COMPLETESTAGE_H_

void simulateCompleteStage();

#endif /* COMPLETESTAGE_H_ */
