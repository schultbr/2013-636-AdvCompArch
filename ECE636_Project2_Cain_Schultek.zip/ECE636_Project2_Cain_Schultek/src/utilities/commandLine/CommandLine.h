/*
 * CommandLine.h
 *
 *  Created on: Oct 22, 2013
 *      Author: brian
 */

#ifndef COMMANDLINE_H_
#define COMMANDLINE_H_

int processCommandLine(int argc, char **argv);

#endif /* COMMANDLINE_H_ */
