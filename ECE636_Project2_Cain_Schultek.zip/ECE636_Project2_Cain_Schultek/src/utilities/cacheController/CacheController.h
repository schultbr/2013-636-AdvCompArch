/*
 * CacheController.h
 *
 *  Created on: Nov 3, 2013
 *      Author: brian
 */

#ifndef CACHECONTROLLER_H_
#define CACHECONTROLLER_H_

int checkCache(float cacheHitRate, int cacheAccessTime);


#endif /* CACHECONTROLLER_H_ */
