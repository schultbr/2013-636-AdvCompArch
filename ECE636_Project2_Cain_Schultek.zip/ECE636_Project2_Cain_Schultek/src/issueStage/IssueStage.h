/*
 * IssueStage.h
 *
 *  Created on: Oct 29, 2013
 *      Author: jason cain
 */

#ifndef ISSUE_H_
#define ISSUE_H_

void simulateIssueStage();

#endif /* ISSUE_H_ */
